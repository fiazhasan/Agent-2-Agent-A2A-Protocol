from python_a2a import AgentNetwork, A2AClient, AIAgentRouter

# Create an agent network
network = AgentNetwork(name="Math Assistant Network")

# Add agents to the network
network.add("add", "http://localhost:5001")
network.add("subtract", "http://localhost:5002")

# Create a router to intelligently direct queries
router = AIAgentRouter(
    llm_client=A2AClient("http://localhost:5000/openai"),
    agent_network=network
)

# Route a query to the appropriate agent
def run_query(query):
    agent_name, confidence = router.route_query(query)
    print(f"Routing to {agent_name} with {confidence:.2f} confidence")
    
    # Get the selected agent and ask the question
    agent = network.get_agent(agent_name)
    response = agent.ask(query)
    print(f"Response: {response}")
    
    # List all available agents
    print("\nAvailable Agents:")
    for agent_info in network.list_agents():
        print(f"- {agent_info['name']}: {agent_info['description']}")

if __name__ == "__main__":
    # Example queries
    run_query("Add 10 and 5")
    run_query("Subtract 8 from 12")