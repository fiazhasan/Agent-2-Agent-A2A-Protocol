from python_a2a import A2AServer, skill, agent, run_server, TaskStatus, TaskState
import re

@agent(
    name="Add Agent",
    description="Performs addition of two numbers",
    version="1.0.0"
)
class AddAgent(A2AServer):
    
    @skill(
        name="Add Numbers",
        description="Add two numbers provided in the query",
        tags=["math", "addition"]
    )
    def add_numbers(self, num1, num2):
        """Add two numbers."""
        return f"The sum of {num1} and {num2} is {num1 + num2}"
    
    def handle_task(self, task):
        # Extract numbers from message
        message_data = task.message or {}
        content = message_data.get("content", {})
        text = content.get("text", "") if isinstance(content, dict) else ""
        
        # Find numbers in the text using regex
        numbers = re.findall(r'\d+\.?\d*', text)
        if len(numbers) >= 2:
            num1, num2 = float(numbers[0]), float(numbers[1])
            result = self.add_numbers(num1, num2)
            task.artifacts = [{
                "parts": [{"type": "text", "text": result}]
            }]
            task.status = TaskStatus(state=TaskState.COMPLETED)
        else:
            task.status = TaskStatus(
                state=TaskState.INPUT_REQUIRED,
                message={"role": "agent", "content": {"type": "text", 
                         "text": "Please provide two numbers to add, e.g., 'Add 5 and 3'."}}
            )
        return task

if __name__ == "__main__":
    agent = AddAgent()
    run_server(agent, port=5001)